"""Fabric sub-modules providing custom installation for non-packaged programs.
"""
