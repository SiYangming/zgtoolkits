"""Download, installation and configuration of biological data.
"""
