.. CloudBioLinux documentation master file, created by
   sphinx-quickstart on Wed Jul 17 09:14:27 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to CloudBioLinux's documentation!
=========================================

.. include:: ../../README.rst
.. include:: framework.rst


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

