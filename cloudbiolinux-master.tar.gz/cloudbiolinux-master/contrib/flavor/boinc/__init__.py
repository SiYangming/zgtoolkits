"""Boinc flavor

   Copyright (C) 2011 Pjotr Prins <pjotr.prins@thebird.nl> and Steffen Moeller <moeller@debian.org>

"""

