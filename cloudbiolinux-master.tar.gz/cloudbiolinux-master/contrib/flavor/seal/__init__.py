"""Seal flavor
"""
